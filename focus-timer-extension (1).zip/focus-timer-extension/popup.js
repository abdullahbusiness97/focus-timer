// popup.js

let blockInterval = null;
let unblockInterval = null;
let openTabs = [];
let selectedSites = new Set();

document.addEventListener("DOMContentLoaded", async () => {
  const data = await chrome.storage.local.get(["blockedSites"]);
  selectedSites = new Set(data.blockedSites || []);

  document.getElementById("startBtn").addEventListener("click", startTimer);
  document.getElementById("refreshTabsBtn").addEventListener("click", loadOpenTabs);

  document.querySelectorAll("#blockPresets .preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const s = parseInt(btn.dataset.preset);
      document.getElementById("blockHours").value = Math.floor(s / 3600);
      document.getElementById("blockMinutes").value = Math.floor((s % 3600) / 60);
      document.getElementById("blockSeconds").value = s % 60;
    });
  });

  document.querySelectorAll("#unblockPresets .preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const s = parseInt(btn.dataset.preset);
      document.getElementById("unblockHours").value = Math.floor(s / 3600);
      document.getElementById("unblockMinutes").value = Math.floor((s % 3600) / 60);
      document.getElementById("unblockSeconds").value = s % 60;
    });
  });

  await loadOpenTabs();
  await syncState();
});

// ── Open Tabs ─────────────────────────────────────────
async function loadOpenTabs() {
  const tabs = await chrome.tabs.query({});
  const seen = new Set();
  openTabs = [];
  for (const tab of tabs) {
    if (!tab.url || tab.url.startsWith("chrome") || tab.url.startsWith("about")) continue;
    try {
      const url = new URL(tab.url);
      const domain = url.hostname.replace(/^www\./, "");
      if (!domain || seen.has(domain)) continue;
      seen.add(domain);
      openTabs.push({ domain, favicon: tab.favIconUrl, title: tab.title });
    } catch (e) {}
  }
  renderTabs();
}

function renderTabs() {
  const list = document.getElementById("tabsList");
  if (openTabs.length === 0) {
    list.innerHTML = `<div class="empty-tabs">No open tabs found.</div>`;
    updateSelectedCount(); return;
  }
  list.innerHTML = "";
  openTabs.forEach(({ domain, favicon }) => {
    const isSelected = selectedSites.has(domain);
    const item = document.createElement("div");
    item.className = `tab-item${isSelected ? " selected" : ""}`;
    item.dataset.domain = domain;
    const faviconHtml = favicon
      ? `<img class="tab-favicon" src="${favicon}" onerror="this.style.display='none'"/>`
      : `<div style="width:15px;height:15px;background:#e4e4e7;border-radius:3px;flex-shrink:0;"></div>`;
    item.innerHTML = `${faviconHtml}<span class="tab-domain">${domain}</span><div class="tab-check"></div>`;
    item.addEventListener("click", () => toggleSite(domain, item));
    list.appendChild(item);
  });
  updateSelectedCount();
}

function toggleSite(domain, el) {
  if (selectedSites.has(domain)) { selectedSites.delete(domain); el.classList.remove("selected"); }
  else { selectedSites.add(domain); el.classList.add("selected"); }
  saveSites(); updateSelectedCount();
}

function updateSelectedCount() {
  const n = selectedSites.size;
  document.getElementById("selectedCount").textContent = n === 0 ? "No sites selected" : `${n} site${n > 1 ? "s" : ""} will be blocked`;
}

async function saveSites() {
  await chrome.storage.local.set({ blockedSites: [...selectedSites] });
}

// ── State Sync ────────────────────────────────────────
async function syncState() {
  const data = await chrome.storage.local.get(["timerActive", "timerEnd", "blocking", "unblockEnd"]);
  if (data.blocking) {
    const unblockRemaining = data.unblockEnd ? Math.floor((data.unblockEnd - Date.now()) / 1000) : 0;
    showBlockedState(Math.max(0, unblockRemaining));
  } else if (data.timerActive && data.timerEnd) {
    const remaining = Math.floor((data.timerEnd - Date.now()) / 1000);
    if (remaining > 0) showActiveState(remaining);
    else showBlockedState(0);
  } else {
    showIdleState();
  }
}

// ── UI States ─────────────────────────────────────────
function showIdleState() {
  clearAllIntervals();
  document.getElementById("setupControls").classList.remove("hidden");
  document.getElementById("timersRow").classList.add("hidden");
  document.getElementById("activeInfo").classList.add("hidden");
  document.getElementById("blockedInfo").classList.add("hidden");
  document.getElementById("blockTimerDisplay").classList.remove("active-block");
  document.getElementById("unblockTimerDisplay").classList.remove("active-unblock");
  setStatus("idle", "Idle");
}

function showActiveState(blockRemaining) {
  document.getElementById("setupControls").classList.add("hidden");
  document.getElementById("timersRow").classList.remove("hidden");
  document.getElementById("activeInfo").classList.remove("hidden");
  document.getElementById("blockedInfo").classList.add("hidden");
  document.getElementById("blockCountdown").classList.add("danger");
  document.getElementById("unblockCountdown").textContent = "--:--:--";
  document.getElementById("blockTimerDisplay").classList.remove("active-block");
  document.getElementById("unblockTimerDisplay").classList.remove("active-unblock");
  setStatus("active", "Active");
  startBlockCountdown(blockRemaining);
}

function showBlockedState(unblockRemaining) {
  clearAllIntervals();
  document.getElementById("setupControls").classList.add("hidden");
  document.getElementById("timersRow").classList.remove("hidden");
  document.getElementById("activeInfo").classList.add("hidden");
  document.getElementById("blockedInfo").classList.remove("hidden");
  document.getElementById("blockCountdown").textContent = "00:00:00";
  document.getElementById("blockTimerDisplay").classList.add("active-block");
  setStatus("blocked", "Blocking");

  if (unblockRemaining > 0) {
    document.getElementById("unblockTimerDisplay").classList.add("active-unblock");
    const el = document.getElementById("autoUnblockIn");
    if (el) el.textContent = formatTime(unblockRemaining);
    startUnblockCountdown(unblockRemaining);
  } else {
    document.getElementById("unblockCountdown").textContent = "--:--:--";
    document.getElementById("blockedInfo").querySelector("p").textContent = "Sites are blocked. Waiting to auto-unblock...";
  }
}

// ── Countdowns ────────────────────────────────────────
function startBlockCountdown(seconds) {
  clearInterval(blockInterval);
  updateBlockDisplay(seconds);
  blockInterval = setInterval(async () => {
    seconds--;
    chrome.runtime.sendMessage({ action: "checkTimerEnd" });
    if (seconds <= 0) {
      clearInterval(blockInterval);
      setTimeout(async () => {
        const data = await chrome.storage.local.get(["blocking", "unblockEnd"]);
        if (data.blocking) {
          const unblockRemaining = data.unblockEnd ? Math.floor((data.unblockEnd - Date.now()) / 1000) : 0;
          showBlockedState(Math.max(0, unblockRemaining));
        }
      }, 600);
      return;
    }
    updateBlockDisplay(seconds);
  }, 1000);
}

function startUnblockCountdown(seconds) {
  clearInterval(unblockInterval);
  updateUnblockDisplay(seconds);
  unblockInterval = setInterval(async () => {
    seconds--;
    chrome.runtime.sendMessage({ action: "checkTimerEnd" });
    if (seconds <= 0) {
      clearInterval(unblockInterval);
      setTimeout(() => showIdleState(), 800);
      return;
    }
    updateUnblockDisplay(seconds);
    const el = document.getElementById("autoUnblockIn");
    if (el) el.textContent = formatTime(seconds);
  }, 1000);
}

function updateBlockDisplay(s) { document.getElementById("blockCountdown").textContent = formatTime(s); }
function updateUnblockDisplay(s) { document.getElementById("unblockCountdown").textContent = formatTime(s); }

function formatTime(secs) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

function clearAllIntervals() {
  clearInterval(blockInterval); blockInterval = null;
  clearInterval(unblockInterval); unblockInterval = null;
}

function pad(n) { return String(n).padStart(2, "0"); }

function setStatus(type, label) {
  document.getElementById("statusBadge").className = `status-badge ${type}`;
  document.getElementById("statusText").textContent = label;
}

// ── Start Timer ───────────────────────────────────────
function startTimer() {
  const bh = parseInt(document.getElementById("blockHours").value) || 0;
  const bm = parseInt(document.getElementById("blockMinutes").value) || 0;
  const bs = parseInt(document.getElementById("blockSeconds").value) || 0;
  const blockTotal = bh * 3600 + bm * 60 + bs;

  const uh = parseInt(document.getElementById("unblockHours").value) || 0;
  const um = parseInt(document.getElementById("unblockMinutes").value) || 0;
  const us = parseInt(document.getElementById("unblockSeconds").value) || 0;
  const unblockTotal = uh * 3600 + um * 60 + us;

  if (blockTotal <= 0) { alert("Please set a block timer greater than 0."); return; }
  if (selectedSites.size === 0) { alert("Please select at least one site to block."); return; }
  if (unblockTotal <= 0) { alert("Please set an unblock timer greater than 0."); return; }

  chrome.runtime.sendMessage({
    action: "startTimer",
    durationSeconds: blockTotal,
    unblockDurationSeconds: unblockTotal
  }, () => {
    showActiveState(blockTotal);
  });
}
