// background.js

chrome.runtime.setUninstallURL("https://abdullahbusiness97.github.io/focus-timer");

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "focusTimerEnd") activateBlocking();
  if (alarm.name === "unblockTimerEnd") deactivateBlocking(true);
});

async function activateBlocking() {
  const data = await chrome.storage.local.get(["blockedSites", "unblockDurationSeconds"]);
  const sites = data.blockedSites || [];
  const unblockDuration = data.unblockDurationSeconds || 0;

  await chrome.storage.local.set({ timerActive: false, blocking: true, timerEnd: null });

  if (sites.length === 0) return;

  const rules = [];
  sites.forEach((site, index) => {
    const clean = site.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/$/, "");
    rules.push({
      id: (index * 2) + 1, priority: 1,
      action: { type: "block" },
      condition: { urlFilter: `||${clean}^`, resourceTypes: ["main_frame", "sub_frame"] }
    });
    rules.push({
      id: (index * 2) + 2, priority: 1,
      action: { type: "block" },
      condition: { urlFilter: `||www.${clean}^`, resourceTypes: ["main_frame", "sub_frame"] }
    });
  });

  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: existing.map(r => r.id),
      addRules: rules
    });

    // Save original URLs of blocked tabs, then redirect them to blocked.html
    const tabs = await chrome.tabs.query({});
    const savedUrls = {};
    for (const tab of tabs) {
      if (!tab.url) continue;
      try {
        const tabHost = new URL(tab.url).hostname.replace(/^www\./, "");
        if (sites.some(s => tabHost === s || tabHost.endsWith("." + s))) {
          savedUrls[tab.id] = tab.url;
          chrome.tabs.update(tab.id, { url: chrome.runtime.getURL("blocked.html") });
        }
      } catch (e) {}
    }
    // Store saved URLs so we can restore them on unblock
    await chrome.storage.local.set({ savedTabUrls: savedUrls });

    // Set auto-unblock alarm if duration is set
    if (unblockDuration > 0) {
      const unblockEnd = Date.now() + unblockDuration * 1000;
      await chrome.storage.local.set({ unblockEnd });
      chrome.alarms.create("unblockTimerEnd", { delayInMinutes: Math.max(unblockDuration / 60, 0.016) });
    }
  } catch (e) {
    console.error("Blocking error:", e);
  }
}

async function deactivateBlocking(restoreTabs = false) {
  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    if (existing.length > 0) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: existing.map(r => r.id),
        addRules: []
      });
    }
  } catch (e) {
    console.error("Deactivate error:", e);
  }

  if (restoreTabs) {
    try {
      const data = await chrome.storage.local.get(["savedTabUrls"]);
      const savedUrls = data.savedTabUrls || {};
      // Navigate blocked.html tabs back to original sites
      const tabs = await chrome.tabs.query({ url: chrome.runtime.getURL("blocked.html") });
      for (const tab of tabs) {
        const originalUrl = savedUrls[tab.id];
        if (originalUrl) {
          chrome.tabs.update(tab.id, { url: originalUrl });
        } else {
          chrome.tabs.update(tab.id, { url: "chrome://newtab/" });
        }
      }
    } catch (e) {}
  }

  await chrome.storage.local.set({
    blocking: false, timerActive: false, timerEnd: null,
    unblockEnd: null, savedTabUrls: {}
  });
  chrome.alarms.clear("unblockTimerEnd");
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.action === "startTimer") {
    const durationSec = message.durationSeconds;
    const timerEnd = Date.now() + durationSec * 1000;
    chrome.storage.local.set({
      timerActive: true, timerEnd, blocking: false,
      unblockDurationSeconds: message.unblockDurationSeconds || 0,
      unblockEnd: null
    });
    deactivateBlocking(false).then(() => {
      chrome.alarms.clear("focusTimerEnd");
      chrome.alarms.clear("unblockTimerEnd");
      chrome.alarms.create("focusTimerEnd", { delayInMinutes: Math.max(durationSec / 60, 0.016) });
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.action === "stopTimer") {
    chrome.alarms.clear("focusTimerEnd");
    chrome.alarms.clear("unblockTimerEnd");
    deactivateBlocking(true).then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.action === "checkTimerEnd") {
    chrome.storage.local.get(["timerActive", "timerEnd", "blocking", "unblockEnd"], (data) => {
      if (data.timerActive && data.timerEnd && Date.now() >= data.timerEnd) {
        activateBlocking();
      }
      if (data.blocking && data.unblockEnd && Date.now() >= data.unblockEnd) {
        deactivateBlocking(true);
      }
    });
    sendResponse({ success: true });
    return true;
  }

});
