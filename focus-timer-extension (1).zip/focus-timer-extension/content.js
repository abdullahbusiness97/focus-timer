// content.js - runs on every page, checks if current site should be blocked

(async () => {
  const data = await chrome.storage.local.get(["blocking", "blockedSites"]);
  if (!data.blocking || !data.blockedSites || data.blockedSites.length === 0) return;

  const currentHost = window.location.hostname.replace(/^www\./, "");
  const isBlocked = data.blockedSites.some(site => {
    const clean = site.replace(/^www\./, "");
    return currentHost === clean || currentHost.endsWith("." + clean);
  });

  if (isBlocked) {
    window.location.replace(chrome.runtime.getURL("blocked.html"));
  }
})();
